package br.com.verificasms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VerificasmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
